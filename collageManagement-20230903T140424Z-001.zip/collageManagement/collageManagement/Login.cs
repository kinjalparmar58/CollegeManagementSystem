﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace collageManagement
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUserName.Text == string.Empty)
            {
                MessageBox.Show("User name is required.");
                txtUserName.Focus();
                return;
            }
            else if (txtPassword.Text == string.Empty)
            {
                MessageBox.Show("Password is required.");
                txtPassword.Focus();
                return;
            }
            else
            {
                try
                {
                    if (DB.Sel("Select * from ULogin where UserName = '" + txtUserName.Text + "' and Password = '" + txtPassword.Text + "'") == true)
                    {
                        DashBoard d = new DashBoard();
                        d.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Incorrect user name or password, Please! Try again.");
                        txtUserName.Focus();
                        txtUserName.SelectAll();
                    }
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            User.ForgetPass forgetpass = new User.ForgetPass();
            forgetpass.ShowDialog();
        }
    }
}
