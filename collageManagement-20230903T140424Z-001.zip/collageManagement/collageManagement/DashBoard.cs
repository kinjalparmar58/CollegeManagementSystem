﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace collageManagement
{
    public partial class DashBoard : Form
    {
        public DashBoard()
        {
          
            InitializeComponent();
            Dt.Text = DateTime.Now.ToString();
            userRole.Text = "Admin";
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                Application.Exit();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
        private void btnHome_Click(object sender, EventArgs e)
        {
           
        }

        private void btnStud_Click(object sender, EventArgs e)
        {
            Student.STab tab = new Student.STab();
            tab.studPanel.AutoScroll = true;
            tab.studPanel.Dock = DockStyle.Fill;
             Controlpanel.Controls.Add(tab.studPanel);
             tab.studPanel.Show(); 
        }

        private void btnCourse_Click(object sender, EventArgs e)
        {
            Course.CTab tab = new Course.CTab();
            tab.TopLevel = false;
            tab.AutoScroll = true;
            tab.Dock = DockStyle.Fill;
            Controlpanel.Controls.Add(tab);
            tab.Show();
        }

       

        private void btnFees_Click(object sender, EventArgs e)
        {
            Fees.FeesDetails Fd = new Fees.FeesDetails();
            Fd.TopLevel = false;
            Fd.AutoScroll = true;
            Fd.Dock = DockStyle.Fill;
       //     Fd.Size = Controlpanel.Size;
            Controlpanel.Controls.Add(Fd);
            Fd.Show();
        }

        private void btnAbout_Click(object sender, EventArgs e)
        {
            frmAboutUs aboutUs = new frmAboutUs();
            aboutUs.TopLevel = false;
            aboutUs.AutoScroll = true;
            aboutUs.Dock = DockStyle.Fill;
            aboutUs.Size = Controlpanel.Size;
            Controlpanel.Controls.Add(aboutUs);
            aboutUs.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Controlpanel.Controls.Clear();
        }

        private void createUser_Click(object sender, EventArgs e)
        {
            User.createUser cu = new User.createUser();
            cu.ShowDialog();
        }

        private void forgotpass_Click(object sender, EventArgs e)
        {
            User.ForgetPass ForgetPass = new User.ForgetPass();
            ForgetPass.ShowDialog();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Controlpanel.Controls.Clear();
            userRole.Visible = false;
            pictureBox2.Visible = false;
            Login login = new Login();
            login.Show();
        }

        private void btnAtten_Click(object sender, EventArgs e)
        {
            Student.STab tab = new Student.STab();
            tab.AttenPanel.AutoScroll = true;
            tab.AttenPanel.Dock = DockStyle.Fill;
            Controlpanel.Controls.Add(tab.AttenPanel);
            tab.AttenPanel.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

     
    }
}
