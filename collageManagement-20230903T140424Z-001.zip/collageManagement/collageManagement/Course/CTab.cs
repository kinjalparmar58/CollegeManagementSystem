﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace collageManagement.Course
{
    public partial class CTab : Form
    {
        public CTab()
        {
            InitializeComponent();
            BindData();
        }
        public string cid, Sid;
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        //course tab

        private void ClearAll()
        {
            txtCourseName.Clear();
            cmbSemester.SelectedIndex = -1;
            txtCourseName.Focus();
        }
       
        private bool CheckValidation()
        {
            if (txtCourseName.Text == string.Empty)
            {
                MessageBox.Show("Course name is required.");
                txtCourseName.Focus();
                return false;
            }
            else if (cmbSemester.Text == string.Empty)
            {
                MessageBox.Show("Semester is not selected.");
                cmbSemester.Focus();
                return false;
            }
            else
            {
                return true;
            }
        }
        public void BindData()
        {
            DataTable dt = DB.getData("select * from Course");
            if (dt.Rows.Count > 0)
            {
                dataGridCourseDetails.DataSource = dt;  
            }
            else
                MessageBox.Show("NO RECORDS FOUND.");
        }
       
    
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!CheckValidation())
                    return;
                if (DB.Sel("INSERT INTO Course values ('" + txtCourseName.Text + "', '" + cmbSemester.Text + "')") == true)
                    MessageBox.Show("Saved Successfully.");
                ClearAll();
                BindData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult DResult;
                DResult = MessageBox.Show("Are you sure want to delete record?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DResult == DialogResult.Yes)
                {
                    if (DB.Sel("Delete from Course where Id = '" + cid + "'") == true)
                    {
                        MessageBox.Show("Delete Successfully.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    ClearAll();
                    dataGridCourseDetails.Rows.Clear();
                    BindData();
                    this.btnSave.Enabled = true;
                    this.btnDelete.Enabled = false;
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message,"", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridCourseDetails_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            this.cid = dataGridCourseDetails.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtCourseName.Text = dataGridCourseDetails.Rows[e.RowIndex].Cells[1].Value.ToString();
            cmbSemester.Text = dataGridCourseDetails.Rows[e.RowIndex].Cells[2].Value.ToString();
            this.btnSave.Enabled = false;
            this.btnDelete.Enabled = true;
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
}
}