﻿namespace collageManagement
{
    partial class DashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ContextMenuStrip newUser;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashBoard));
            this.createUser = new System.Windows.Forms.ToolStripMenuItem();
            this.forgotpass = new System.Windows.Forms.ToolStripMenuItem();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnAbout = new System.Windows.Forms.Button();
            this.btnUser = new System.Windows.Forms.Button();
            this.btnFees = new System.Windows.Forms.Button();
            this.btnCourse = new System.Windows.Forms.Button();
            this.btnAtten = new System.Windows.Forms.Button();
            this.btnStud = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.Controlpanel = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.userRole = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Dt = new System.Windows.Forms.Label();
            newUser = new System.Windows.Forms.ContextMenuStrip(this.components);
            newUser.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // newUser
            // 
            newUser.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            newUser.ImeMode = System.Windows.Forms.ImeMode.On;
            newUser.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createUser,
            this.forgotpass});
            newUser.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Table;
            newUser.Name = "newUser";
            newUser.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            newUser.Size = new System.Drawing.Size(226, 64);
            newUser.Text = "newUser";
            // 
            // createUser
            // 
            this.createUser.Name = "createUser";
            this.createUser.Size = new System.Drawing.Size(225, 30);
            this.createUser.Text = "Create User";
            this.createUser.Click += new System.EventHandler(this.createUser_Click);
            // 
            // forgotpass
            // 
            this.forgotpass.Name = "forgotpass";
            this.forgotpass.Size = new System.Drawing.Size(225, 30);
            this.forgotpass.Text = "Forgot Password";
            this.forgotpass.Click += new System.EventHandler(this.forgotpass_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Navy;
            this.panel6.Controls.Add(this.panel1);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel6.Location = new System.Drawing.Point(1354, 0);
            this.panel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(11, 686);
            this.panel6.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Navy;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(11, 686);
            this.panel1.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Navy;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(236, 686);
            this.panel2.TabIndex = 4;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Font = new System.Drawing.Font("Lucida Fax", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(0, 161);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(236, 525);
            this.panel3.TabIndex = 4;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panel10);
            this.panel5.Controls.Add(this.btnAbout);
            this.panel5.Controls.Add(this.btnUser);
            this.panel5.Controls.Add(this.btnFees);
            this.panel5.Controls.Add(this.btnCourse);
            this.panel5.Controls.Add(this.btnAtten);
            this.panel5.Controls.Add(this.btnStud);
            this.panel5.Controls.Add(this.panel4);
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(236, 525);
            this.panel5.TabIndex = 0;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.button1);
            this.panel10.Controls.Add(this.btnLogout);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel10.Location = new System.Drawing.Point(0, 493);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(226, 32);
            this.panel10.TabIndex = 11;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Dock = System.Windows.Forms.DockStyle.Right;
            this.button1.Location = new System.Drawing.Point(4, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 32);
            this.button1.TabIndex = 11;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Red;
            this.btnLogout.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnLogout.Location = new System.Drawing.Point(115, 0);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(111, 32);
            this.btnLogout.TabIndex = 10;
            this.btnLogout.Text = "LogOut";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnAbout
            // 
            this.btnAbout.BackColor = System.Drawing.Color.LightGray;
            this.btnAbout.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAbout.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnAbout.FlatAppearance.BorderSize = 10;
            this.btnAbout.FlatAppearance.CheckedBackColor = System.Drawing.Color.DimGray;
            this.btnAbout.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnAbout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Cornsilk;
            this.btnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAbout.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbout.Location = new System.Drawing.Point(0, 335);
            this.btnAbout.Margin = new System.Windows.Forms.Padding(5);
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.Padding = new System.Windows.Forms.Padding(10);
            this.btnAbout.Size = new System.Drawing.Size(226, 65);
            this.btnAbout.TabIndex = 9;
            this.btnAbout.TabStop = false;
            this.btnAbout.Text = "ABOUT US";
            this.btnAbout.UseVisualStyleBackColor = false;
            this.btnAbout.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // btnUser
            // 
            this.btnUser.BackColor = System.Drawing.Color.LightGray;
            this.btnUser.ContextMenuStrip = newUser;
            this.btnUser.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnUser.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnUser.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnUser.FlatAppearance.BorderSize = 10;
            this.btnUser.FlatAppearance.CheckedBackColor = System.Drawing.Color.DimGray;
            this.btnUser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Cornsilk;
            this.btnUser.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUser.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUser.Location = new System.Drawing.Point(0, 270);
            this.btnUser.Margin = new System.Windows.Forms.Padding(5);
            this.btnUser.Name = "btnUser";
            this.btnUser.Padding = new System.Windows.Forms.Padding(10);
            this.btnUser.Size = new System.Drawing.Size(226, 65);
            this.btnUser.TabIndex = 8;
            this.btnUser.TabStop = false;
            this.btnUser.Text = "USER SETTINGS";
            this.btnUser.UseVisualStyleBackColor = false;
            // 
            // btnFees
            // 
            this.btnFees.BackColor = System.Drawing.Color.LightGray;
            this.btnFees.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnFees.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnFees.FlatAppearance.BorderSize = 10;
            this.btnFees.FlatAppearance.CheckedBackColor = System.Drawing.Color.DimGray;
            this.btnFees.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnFees.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Cornsilk;
            this.btnFees.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFees.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFees.Location = new System.Drawing.Point(0, 205);
            this.btnFees.Margin = new System.Windows.Forms.Padding(5);
            this.btnFees.Name = "btnFees";
            this.btnFees.Padding = new System.Windows.Forms.Padding(10);
            this.btnFees.Size = new System.Drawing.Size(226, 65);
            this.btnFees.TabIndex = 7;
            this.btnFees.TabStop = false;
            this.btnFees.Text = "FEES";
            this.btnFees.UseVisualStyleBackColor = false;
            this.btnFees.Click += new System.EventHandler(this.btnFees_Click);
            // 
            // btnCourse
            // 
            this.btnCourse.BackColor = System.Drawing.Color.LightGray;
            this.btnCourse.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCourse.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnCourse.FlatAppearance.BorderSize = 10;
            this.btnCourse.FlatAppearance.CheckedBackColor = System.Drawing.Color.DimGray;
            this.btnCourse.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnCourse.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Cornsilk;
            this.btnCourse.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCourse.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCourse.Location = new System.Drawing.Point(0, 140);
            this.btnCourse.Margin = new System.Windows.Forms.Padding(5);
            this.btnCourse.Name = "btnCourse";
            this.btnCourse.Padding = new System.Windows.Forms.Padding(10);
            this.btnCourse.Size = new System.Drawing.Size(226, 65);
            this.btnCourse.TabIndex = 6;
            this.btnCourse.TabStop = false;
            this.btnCourse.Text = "COURSE";
            this.btnCourse.UseVisualStyleBackColor = false;
            this.btnCourse.Click += new System.EventHandler(this.btnCourse_Click);
            // 
            // btnAtten
            // 
            this.btnAtten.BackColor = System.Drawing.Color.LightGray;
            this.btnAtten.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAtten.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnAtten.FlatAppearance.BorderSize = 10;
            this.btnAtten.FlatAppearance.CheckedBackColor = System.Drawing.Color.DimGray;
            this.btnAtten.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnAtten.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Cornsilk;
            this.btnAtten.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAtten.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtten.Location = new System.Drawing.Point(0, 75);
            this.btnAtten.Margin = new System.Windows.Forms.Padding(5);
            this.btnAtten.Name = "btnAtten";
            this.btnAtten.Padding = new System.Windows.Forms.Padding(10);
            this.btnAtten.Size = new System.Drawing.Size(226, 65);
            this.btnAtten.TabIndex = 5;
            this.btnAtten.TabStop = false;
            this.btnAtten.Text = "ATTENDANCE";
            this.btnAtten.UseVisualStyleBackColor = false;
            this.btnAtten.Click += new System.EventHandler(this.btnAtten_Click);
            // 
            // btnStud
            // 
            this.btnStud.BackColor = System.Drawing.Color.LightGray;
            this.btnStud.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnStud.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnStud.FlatAppearance.BorderSize = 10;
            this.btnStud.FlatAppearance.CheckedBackColor = System.Drawing.Color.DimGray;
            this.btnStud.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnStud.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Cornsilk;
            this.btnStud.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnStud.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStud.Location = new System.Drawing.Point(0, 10);
            this.btnStud.Margin = new System.Windows.Forms.Padding(5);
            this.btnStud.Name = "btnStud";
            this.btnStud.Padding = new System.Windows.Forms.Padding(10);
            this.btnStud.Size = new System.Drawing.Size(226, 65);
            this.btnStud.TabIndex = 4;
            this.btnStud.TabStop = false;
            this.btnStud.Text = "STUDENT";
            this.btnStud.UseVisualStyleBackColor = false;
            this.btnStud.Click += new System.EventHandler(this.btnStud_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Navy;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(226, 10);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(10, 515);
            this.panel4.TabIndex = 1;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Navy;
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(236, 10);
            this.panel7.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.RoyalBlue;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Image = global::collageManagement.Properties.Resources.CMS;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(236, 161);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.Controlpanel);
            this.panel8.Controls.Add(this.panel9);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(236, 0);
            this.panel8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1118, 686);
            this.panel8.TabIndex = 6;
            // 
            // Controlpanel
            // 
            this.Controlpanel.BackColor = System.Drawing.Color.Silver;
            this.Controlpanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Controlpanel.BackgroundImage")));
            this.Controlpanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controlpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Controlpanel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Controlpanel.Location = new System.Drawing.Point(0, 52);
            this.Controlpanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Controlpanel.Name = "Controlpanel";
            this.Controlpanel.Size = new System.Drawing.Size(1118, 634);
            this.Controlpanel.TabIndex = 0;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.MenuText;
            this.panel9.Controls.Add(this.userRole);
            this.panel9.Controls.Add(this.pictureBox2);
            this.panel9.Controls.Add(this.Dt);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1118, 52);
            this.panel9.TabIndex = 1;
            // 
            // userRole
            // 
            this.userRole.AutoSize = true;
            this.userRole.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.userRole.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userRole.ForeColor = System.Drawing.Color.Cornsilk;
            this.userRole.Location = new System.Drawing.Point(56, 17);
            this.userRole.Name = "userRole";
            this.userRole.Padding = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.userRole.Size = new System.Drawing.Size(100, 35);
            this.userRole.TabIndex = 2;
            this.userRole.Text = "UserRole";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox2.Image = global::collageManagement.Properties.Resources.Login;
            this.pictureBox2.InitialImage = global::collageManagement.Properties.Resources.Login;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(56, 52);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // Dt
            // 
            this.Dt.AutoSize = true;
            this.Dt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dt.ForeColor = System.Drawing.Color.Cornsilk;
            this.Dt.Location = new System.Drawing.Point(857, 0);
            this.Dt.Name = "Dt";
            this.Dt.Size = new System.Drawing.Size(119, 29);
            this.Dt.TabIndex = 0;
            this.Dt.Text = "DateTime";
            this.Dt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // DashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1365, 686);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel6);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DashBoard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            newUser.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label userRole;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label Dt;
        private System.Windows.Forms.Button btnAbout;
        private System.Windows.Forms.Button btnUser;
        private System.Windows.Forms.Button btnFees;
        private System.Windows.Forms.Button btnCourse;
        private System.Windows.Forms.Button btnAtten;
        private System.Windows.Forms.Button btnStud;
        public System.Windows.Forms.Panel Controlpanel;
        private System.Windows.Forms.ToolStripMenuItem createUser;
        private System.Windows.Forms.ToolStripMenuItem forgotpass;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button button1;
    }
}

