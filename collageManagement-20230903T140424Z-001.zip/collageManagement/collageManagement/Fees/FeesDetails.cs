﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;
using System.Drawing.Printing;
using System.Threading.Tasks;

namespace collageManagement.Fees
{
    public partial class FeesDetails : Form
    {
        public FeesDetails()
        {
            InitializeComponent();
            disp();
        }
        string fid ;
        int a;
        private void ClearAllA()
        {
            txtStudentName.Clear();
            txtRollNo.Clear();
            txtCourse.Clear();
            txtSemester.Clear();
            cmbCourse.Focus();
        }
        public void getAmt()
        {
            if (DB.Sel("Select * from FeeDetails where StudentName = '" + cmbNm.Text + "'"))
            {
                DataTable dt1 = DB.getData("Select * from FeeDetails Where StudentName = '" + cmbNm.Text + "'");
                txtAmount.Text = dt1.Rows[0][8].ToString();
            }
            else
            {
                DataTable dt1 = DB.getData("Select * from FeeManage Where Class = '" + cmbCourse.Text + "'");
                txtAmount.Text = dt1.Rows[0][2].ToString();
            }
        }
        public void disp()
        {
            DataTable dt = DB.getData("select  DISTINCT Course from RegStudent");
            cmbCourse.DataSource = dt;
            cmbCourse.DisplayMember = "Course";
        }
        
        private void cmbCourse_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt = DB.getData("SELECT Distinct Semester from RegStudent where Course = '" + cmbCourse.Text + "'");
            cmbSemester.DataSource = dt;
            cmbSemester.DisplayMember = "Semester";
            cmbSemester.Enabled = true;
        }

        private void cmbSemester_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt = DB.getData("Select * from RegStudent where Semester = '" + cmbSemester.Text + "'");
            cmbNm.DataSource = dt;
            cmbNm.DisplayMember = "StudentName";
            cmbNm.Enabled = true;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (this.cmbNm.Text == string.Empty)
            {
                MessageBox.Show("Please select Name", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                cmbNm.Focus();
                return;
            }
            string sql = "Select * from RegStudent where Course = '" + cmbCourse.Text + "' and  Semester = '" + cmbSemester.Text + "' and StudentName = '" + cmbNm.Text + "'";
            DataTable dt = DB.getData(sql);
            txtRollNo.Text = dt.Rows[0][1].ToString();
            txtStudentName.Text = cmbNm.Text;
            txtCourse.Text = cmbCourse.Text;
            txtSemester.Text = cmbSemester.Text;
            getAmt();
           
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtPaidAmount.Text == string.Empty)
            {
                MessageBox.Show("Please enter value");
            }
            else
            {
                try
                {
                    if (DB.Sel("Select * from FeeDetails where StudentName = '" + cmbNm.Text + "'"))
                    {
                        DataTable dt1 = DB.getData("Select PaidAmount from FeeDetails where StudentName = '" + cmbNm.Text + "'");
                        int totalPaidAmt = Convert.ToInt32(txtPaidAmount.Text) + Convert.ToInt32(dt1.Rows[0][0]);
                        //MessageBox.Show(totalPaidAmt.ToString());
                        string sql = "Update FeeDetails set DueAmount = '" + txtDueAmount.Text + "' ,PaidAmount ='" + totalPaidAmt.ToString() + "' where StudentName = '" + cmbNm.Text + "'";
                       DataTable dt = DB.getData(sql);
                    }
                    else
                    {
                        string sql = "Insert into FeeDetails values('" + txtRollNo.Text + "','" + txtStudentName.Text + "','" + txtCourse.Text + "','" + txtSemester.Text + "','" + mtxtPaidDate.Text + "','" + txtAmount.Text + "','" + txtPaidAmount.Text + "','" + txtDueAmount.Text + "') ";
                        DataTable dt = DB.getData(sql);
                    }
                    MessageBox.Show("Saved Successfully.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearAllA();
                    txtnm.Text = cmbNm.Text;
                    txtC.Text = cmbCourse.Text;
                    txtSem.Text = cmbSemester.Text;
                    txtDt.Text = mtxtPaidDate.Text;
                    tableLayoutPanel1.Visible = true;
                     txtPAmt.Text = txtPaidAmount.Text;
                     btnSave.Enabled = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            } 
        }

        private void txtPaidAmount_TextChanged(object sender, EventArgs e)
        {
            if (!txtPaidAmount.Text.All(Char.IsDigit))
            {
                MessageBox.Show("only Digits Are Allowed");
            }
            try
            {
                a = Convert.ToInt32(txtAmount.Text) - Convert.ToInt32(txtPaidAmount.Text);
                txtDueAmount.Text = a.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbNm_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
           Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            PrintDocument doc = new PrintDocument();
            doc.PrintPage += this.printDocument1_PrintPage;

            PrintDialog dlg = new PrintDialog();
            dlg.Document = doc;
            if (dlg.ShowDialog() == DialogResult.OK)
            {
               printDialog1.ShowDialog();
              
                doc.Print();
               dlg.ShowDialog();
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            float x = e.MarginBounds.Left;
            float y = e.MarginBounds.Top;
            Bitmap bmp = new Bitmap(panel2.Width, panel2.Height);
            FeeRecipt.DrawToBitmap(bmp, new Rectangle(0, 0, panel2.Width, panel2.Height));
            e.Graphics.DrawImage((Image)bmp, x, y);
           
        }

       
    }
}
