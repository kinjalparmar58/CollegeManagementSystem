﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.Drawing.Imaging;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;
using Microsoft.VisualBasic;

namespace collageManagement.Student
{
    class StudEdit
    {
        public const String Emailpattern =  @"^([0-9a-zA-Z]" +  @"([\+\-_\.][0-9a-zA-Z]+)*" +  @")+" + @"@(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]*\.)+[a-zA-Z0-9]{2,17})$";
        public static bool getInvalidInput(string InputBox, string ExpressionPattern, string Message)
        {
            bool valid;

            valid = Regex.Match(InputBox, ExpressionPattern).Success;
            if (!valid)
            {
                MessageBox.Show(Message);
            }
            return valid;
        }
        //stud details
        private string _sid;
        private string _studentname;
        private string _rollno;
        private string _gender;
        private string _address;
        private string _dateofbirth;
        private string _admissiondate;
        private string _phoneno;
        private string _email;
        private string _shift;
        private string _course;
        private string _semester;
        private string _studentphoto;
   
        // Student attendance details
        private int _attendanceid;
        private string _courseid;
        private string _attendancedate;
        private string _attendance;
 
        //stud dtails property
        public string SId
        {
            get { return _sid; }
            set { _sid = value; }
        }

        public string StudentName
        {
            get { return _studentname; }
            set { _studentname = value; }
        }

        public string RollNo
        {
            get { return _rollno; }
            set { _rollno = value; }
        }

        public string Gender
        {
            get { return _gender; }
            set { _gender = value; }
        }

        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }

        public string DateOfBirth
        {
            get { return _dateofbirth; }
            set { _dateofbirth = value; }
        }

        public string AdmissionDate
        {
            get { return _admissiondate; }
            set { _admissiondate = value; }
        }

        public string PhoneNumber
        {
            get { return _phoneno; }
            set { _phoneno = value; }
        }

        public string EmailId
        {
            get { return _email; }
            set { _email = value; }
        }

        public string Shift
        {
            get { return _shift; }
            set { _shift = value; }
        }

        public string Course
        {
            get { return _course; }
            set { _course = value; }
        }

        public string Semester
        {
            get { return _semester; }
            set { _semester = value; }
        }

        public string StudentPicture
        {
            get { return _studentphoto; }
            set { _studentphoto = value; }
        }

        //Atten property
        public int AttendenceId
        {
            get { return _attendanceid; }
            set { _attendanceid = value; }
        }

        public string CourseId
        {
            get { return _courseid; }
            set { _courseid = value; }
        }

        public string AttendenceDate
        {
            get { return _attendancedate; }
            set { _attendancedate = value; }
        }

        public string Attendence
        {
            get { return _attendance; }
            set { _attendance = value; }
        }
       
        public void AddStud()
        {
            string sql = "INSERT INTO Regstudent values ('" + _rollno + "', '" + _studentname + "','" + _gender + "','" + _address + "','" + _dateofbirth + "','" + _admissiondate + "','" + _phoneno + "','" + _email + "','" + _shift + "','" + _course + "','" + _semester + "','" + _studentphoto + "')";
            DB.Sel(sql);
        }
        public void update()
        {
            DB.Sel("Update Regstudent Set RollNo='"+_rollno+"', StudentName='"+_studentname+"', Gender='"+_gender+"', Address='"+_address+"', DateOfBirth='"+_dateofbirth+"', AdmissionDate='"+_admissiondate+"', PhoneNo='"+_phoneno+"', Email='"+_email+"', Shift='"+_shift+"', Course='"+_course+"', Semester='"+_semester+"' Where Id='"+_sid+"'");
        }

        //Attendence
        public void AddAtten()
        {
            DB.Sel("INSERT INTO StuAttendence Values('" + _attendancedate + "', '" + _attendance + "', '" + Convert.ToInt32(_sid) + "')");
            
        }
    }


}
