﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;

namespace collageManagement.Student
{
    public partial class STab : Form
    {
        public STab()
        {
            InitializeComponent();
            DashBoard d = new DashBoard();
            this.Size = d.Controlpanel.Size;
            CourseList();
            AttenCourseList();
            BindData();
        }
        string folderPath;
        StudEdit stud = new StudEdit();
        private string StudentId;
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        //Stud Details 
        public bool DetailsValidation()
        {
            bool isValid = true;
            if (txtRollNo.Text == string.Empty)
            {
                MessageBox.Show("Roll number is required.","", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtRollNo.Focus();
                isValid = false;
            }
            else if (txtStudentName.Text == string.Empty)
                {
                    MessageBox.Show("Student name is required.","", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtStudentName.Focus();
                    isValid = false;
                }
            else if (rdMale.Checked == false && rdFemale.Checked == false)
                    {
                        MessageBox.Show("Select Gender.","", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        isValid = false;
                    }
            else if (txtAddress.Text == string.Empty)
            { 
                            MessageBox.Show("Address is required.","", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            txtAddress.Focus();
                            isValid = false;
            }
            else if (txtPhoneNo.Text == string.Empty)
            {
                    MessageBox.Show("Phone number is required.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtPhoneNo.Focus();
                    isValid = false;
            }
            else if (!txtPhoneNo.Text.All(Char.IsDigit))
             {
                  MessageBox.Show("Phone no can not accepted charecter", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                  txtPhoneNo.Focus();
                  txtPhoneNo.SelectAll();
                  isValid = false;
             }
             else if (txtPhoneNo.Text.Trim().Length < 10)
             {
                 MessageBox.Show("Phone number length must be 10 digits accept.","", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                 txtPhoneNo.SelectAll();
                 txtPhoneNo.Focus();
                 isValid = false;
             }
              else if (txtEmail.Text == string.Empty)
              {
                  MessageBox.Show("Email id is required.","", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                  txtEmail.Focus();
                  isValid = false;
              }
            else if (!StudEdit.getInvalidInput(txtEmail.Text, StudEdit.Emailpattern ,"Invalid email. give email in correct format"))
            {
                  txtEmail.SelectAll();
                  txtEmail.Focus();
                  isValid = false; ;
            }
            return isValid;
        }
        private void ClearAll()
        {
            this.StudentId = "";
            this.txtRollNo.Clear();
            this.txtStudentName.Clear();
            this.rdMale.Checked = false;
            this.rdFemale.Checked = false;
            this.txtAddress.Clear();
            this.txtPhoneNo.Clear();
            this.txtEmail.Clear();
            this.cmbShift.SelectedIndex = -1;
            this.cmbCourse.SelectedIndex = -1;
            this.cmbSemester.SelectedIndex = -1;
            this.picStudent.Image = null;
            this.cmbFilter.SelectedIndex = 0;
            this.txtSearch.Clear();
            this.txtRollNo.Focus();
        }
        public void BindData()
        {
            DataTable dt = DB.getData("Select Id,RollNo,StudentName,Gender,Address,DateOfBirth,AdmissionDate,PhoneNo,Email,Shift,Course,Semester from RegStudent");
            if (dt.Rows.Count > 0)
            {
                dataStudentView.DataSource = dt;
            }
        }
        private void mtxtDOB_TypeValidationCompleted(object sender, TypeValidationEventArgs e)
        {
            if (this.ActiveControl == mtxtDOB)
                return;
            if (!e.IsValidInput)
            {
                MessageBox.Show("Date of birth or Empty\nThe Date supplied must be a valid date in the format dd/mm/yyyy.","", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Cancel = true;
                mtxtDOB.Focus();
            }
        }

        private void mtxtAdmissionDate_TypeValidationCompleted(object sender, TypeValidationEventArgs e)
        {
            if (this.ActiveControl == mtxtAdmissionDate)
                return;
            if (!e.IsValidInput)
            {
                MessageBox.Show("Addmision Date or Empty\nThe Date supplied must be a valid date in the format dd/mm/yyyy.","", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Cancel = true;
                mtxtAdmissionDate.Focus();
            }
        }

        private void GetDataBind(string sql)
        {

            DataTable dt = DB.getData(sql);
           
            if (dt.Rows.Count > 0)
            {
                StudentId = dt.Rows[0]["Id"].ToString();
                txtRollNo.Text = dt.Rows[0]["RollNo"].ToString();
                txtStudentName.Text = dt.Rows[0]["StudentName"].ToString();
                if (dt.Rows[0]["Gender"].ToString().Trim().Equals("Male") == true)
                {
                    this.rdMale.Checked = true;
                }
                else
                {
                    this.rdFemale.Checked = true;
                }
                txtAddress.Text = dt.Rows[0]["Address"].ToString();
                mtxtDOB.Text = dt.Rows[0]["DateOfBirth"].ToString();
                mtxtAdmissionDate.Text = dt.Rows[0]["AdmissionDate"].ToString();
                txtPhoneNo.Text = dt.Rows[0]["PhoneNo"].ToString();
                txtEmail.Text = dt.Rows[0]["Email"].ToString();
                cmbShift.Text = dt.Rows[0]["Shift"].ToString();
                cmbCourse.Text = dt.Rows[0]["Course"].ToString();
                cmbSemester.Text = dt.Rows[0]["Semester"].ToString();
            }
            else
            {
                MessageBox.Show("Record not found!","", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtSearch.Focus();
                txtSearch.SelectAll();
            }
        }
        public void fetchData()
        {
            stud.StudentName = txtStudentName.Text;
            stud.RollNo = txtRollNo.Text;
            if (this.rdMale.Checked == true)
            {
                stud.Gender = rdMale.Text;
            }
            else if (this.rdFemale.Checked == true)
                {
                    stud.Gender = rdFemale.Text;
                }
            stud.Address = txtAddress.Text;
            stud.DateOfBirth = mtxtDOB.Text;
            stud.AdmissionDate = mtxtAdmissionDate.Text;
            stud.PhoneNumber = txtPhoneNo.Text;
            stud.EmailId = txtEmail.Text;
            stud.StudentPicture =  fileName;
            stud.Shift = cmbShift.Text;
            stud.Course = cmbCourse.Text;
            stud.Semester = cmbSemester.Text;
        }
        private void SearchDetails(string ListType, string getText)
        {
            switch (ListType)
            {
                case "Roll no":
                    GetDataBind("SELECT * From Regstudent WHERE RollNo='" + getText.Trim() + "'");
                    break;
                case "Student name":
                    GetDataBind("SELECT * From Regstudent WHERE StudentName='" + getText.Trim() + "'");
                    break;
            }
            stud.SId = StudentId;
        }
        private void CourseList()
        {
            DataTable dt = DB.getData("SELECT Distinct CourseName from Course");
            cmbCourse.DataSource = dt;
            cmbCourse.DisplayMember = "CourseName";
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!DetailsValidation())
                {
                    return;
                }
                fetchData();
                stud.AddStud();
                MessageBox.Show("Saved Successfully.","", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearAll();
                //dataStudentView.Rows.Clear();
                BindData();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.ToString(),"", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRollNo.Focus();
            }
        }
        string fileName;
        private void btnUpload_Click(object sender, EventArgs e)
        {
            folderPath = Application.StartupPath+ "\\Images";
            MessageBox.Show(folderPath);
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Filter = "JPEG|*.jpg|All files|*.*";
            DialogResult rs = openFile.ShowDialog();
            if (rs == DialogResult.OK)
            {
                try
                {
                    fileName = Path.GetFileName(openFile.FileName);
                    string fileSavePath = Path.Combine(folderPath, fileName);
                    MessageBox.Show(fileSavePath);
                    picStudent.Image = null;
                    picStudent.Image = Image.FromFile(openFile.FileName);
                    MessageBox.Show(openFile.FileName);
                    File.Copy(openFile.FileName, fileSavePath, true);
                }
                catch (IOException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (!DetailsValidation())
                {
                    return;
                }
                fetchData();
                stud.update();
                MessageBox.Show("Update Successfully.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearAll();
                BindData();
                this.btnSave.Enabled = true;
                this.btnUpdate.Enabled = false;
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRollNo.Focus();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            studPanel.Hide();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (this.txtSearch.Text == string.Empty)
            {
                MessageBox.Show("Type " + cmbFilter.Text + "!", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtSearch.Focus();
                return;
            }
            else
            {
                SearchDetails(cmbFilter.Text, txtSearch.Text);
                this.btnSave.Enabled = false;
                this.btnUpdate.Enabled = true;
            
            }
        }

        private void cmbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.picStudent.Visible = false;
            this.btnUpload.Visible = false;
            if (this.cmbFilter.Text == "(None)")
            {
                this.txtSearch.Enabled = false;
                this.btnSearch.Enabled = false;
                this.picStudent.Visible = true;
                this.btnUpload.Visible = true;
            }
            else
            {
                this.txtSearch.Enabled = true;
                this.btnSearch.Enabled = true;
                
            }
        }

        private void dataStudentView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            this.btnSave.Enabled = false;
            this.btnUpdate.Enabled = true;
        }
        //Stud Atten
        private void CheckDataGridTable()
        {
            if (this.gridStudentAttendanceData.Rows.Count != 0)
            {
                this.btnConform.Enabled = true;
            }
            else
            {
                this.btnConform.Enabled = false;
            }
        }
        private void AttenCourseList()
        {
            DataTable dt = DB.getData("SELECT Distinct Course from RegStudent");
            cmbAttenCourse.DataSource = dt;
            cmbAttenCourse.DisplayMember = "Course";
            cmbSemester.Enabled = true;
        }

        private void cmbAttenCourse_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbSemester.Enabled = true;
            string sql = "SELECT Semester from RegStudent Where Course='" + cmbAttenCourse.Text + "'";
            DataTable dt = DB.getData(sql);
            if (dt.Rows.Count > 0)
            {
                cmbattenSem.DataSource = dt;
                cmbattenSem.DisplayMember = "Semester";
         
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = " SELECT Id,RollNo,StudentName from RegStudent where  Course='" + cmbAttenCourse.Text + "' and Semester = '" + cmbattenSem.Text + "'";
                DataTable dt = DB.getData(sql);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        gridStudentAttendanceData.Rows.Add();
                        gridStudentAttendanceData.Rows[gridStudentAttendanceData.Rows.Count - 1].Cells["studID"].Value = dt.Rows[i][0];
                        gridStudentAttendanceData.Rows[gridStudentAttendanceData.Rows.Count - 1].Cells["Roll"].Value = dt.Rows[i][1];
                        gridStudentAttendanceData.Rows[gridStudentAttendanceData.Rows.Count - 1].Cells["StudName"].Value = dt.Rows[i][2];
                        gridStudentAttendanceData.Rows[gridStudentAttendanceData.Rows.Count - 1].Cells["date"].Value = DateTime.Today.ToShortDateString();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnConform_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < gridStudentAttendanceData.Rows.Count; i++)
                {
                    stud.AttendenceDate = gridStudentAttendanceData.Rows[i].Cells["date"].Value.ToString();
                    stud.Attendence = gridStudentAttendanceData.Rows[i].Cells["Atten"].Value.ToString();
                    stud.SId = gridStudentAttendanceData.Rows[i].Cells["studID"].Value.ToString();
                    MessageBox.Show(stud.Attendence + stud.AttendenceDate + stud.SId);
                    stud.AddAtten();
                }
                MessageBox.Show("Saved Successfully.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                gridStudentAttendanceData.Rows.Clear();
                CheckDataGridTable();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message,"", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            AttenPanel.Hide();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            ClearAll();
            btnUpdate.Enabled = false;
            btnSave.Enabled = true;
        }
    }
}
