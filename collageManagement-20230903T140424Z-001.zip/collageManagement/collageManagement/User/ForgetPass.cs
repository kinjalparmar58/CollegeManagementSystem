﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace collageManagement.User
{
    public partial class ForgetPass : Form
    {
        public ForgetPass()
        {
            InitializeComponent();
        }
        private bool Validation()
        {
            bool isValid = true;
            if (txtUserName.Text == string.Empty && txtNewPassword.Text == string.Empty && txtConfirmPassword.Text == string.Empty)
            {
                MessageBox.Show("All Fields are required","", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNewPassword.Focus();
                isValid = false;
            }
            if (txtNewPassword.Text != txtConfirmPassword.Text)
            {
                MessageBox.Show("PASSWORD IS NOT MATCH", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtConfirmPassword.Clear();
                txtNewPassword.Focus();
                txtNewPassword.SelectAll();
                isValid = false; ;
            }
            return isValid;
        }
        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            try
            {
                DB.Sel("Update ULogin set Password = '" + txtConfirmPassword.Text + "' where UserName = '" + txtUserName.Text + "' ");
                MessageBox.Show("Password Changed Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtNewPassword.Clear();
                txtConfirmPassword.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
