﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace collageManagement.User
{
    public partial class createUser : Form
    {
        public createUser()
        {
            InitializeComponent();
        }
        private bool Validation()
        {
            bool isValid = true;
            if (txtUserName.Text == string.Empty && txtPassword.Text == string.Empty && txtConfirmPSW.Text == string.Empty)
            {
                this.label2.ForeColor = Color.Red;
                this.label2.Text = "All Fields is required.";
                isValid = false;
            }
            if (txtPassword.Text != txtConfirmPSW.Text)
            {
                this.label2.ForeColor = Color.Red;
                this.label2.Text = "Password or confirm password is not matched.";
                txtConfirmPSW.Clear();
                txtPassword.Focus();
                txtPassword.SelectAll();
                isValid = false; ;
            }
            return isValid;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Validation())
                {
                    return;
                }
                else
                {
                    DB.Sel("Insert into ULogin values('"+txtUserName.Text+"','"+txtConfirmPSW.Text+"')");
                    this.label2.ForeColor = Color.Green;
                    this.label2.Text = "New user create successfully.";
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message,"", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
